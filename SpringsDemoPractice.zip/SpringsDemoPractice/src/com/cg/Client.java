package com.cg;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
public class Client {
	public static void main(String[] args) {
		AbstractApplicationContext ctx = new AnnotationConfigApplicationContext(Config.class);
		Mall m=(Mall)ctx.getBean("mall");
		System.out.println(m.getmId()+" "+m.getmName()+" "+m.getTheatre().gettId()+" "+m.getTheatre().gettName()+" "+m.getTheatre().getSeats().getsNo());
	}
}