package com.cg;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

@Component("mall")
public class Mall {
	private int mId=101;
	private String mName="Avengers";
	@Resource(name="theatre")
	private Theatre theatre;

	public int getmId() {
		return mId;
	}

	public void setmId(int mId) {
		this.mId = mId;
	}

	public String getmName() {
		return mName;
	}

	public void setmName(String mName) {
		this.mName = mName;
	}

	public Theatre getTheatre() {
		return theatre;
	}

	public void setTheatre(Theatre theatre) {
		this.theatre = theatre;
	}

}
