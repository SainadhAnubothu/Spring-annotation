package com.cg;

import org.springframework.stereotype.Component;

@Component("seats")
public class Seats {
	private int sNo = 1;

	public int getsNo() {
		return sNo;
	}

	public void setsNo(int sNo) {
		this.sNo = sNo;
	}

}
