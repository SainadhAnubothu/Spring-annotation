package com.cg;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

@Component("theatre")
public class Theatre {
	private int tId=123;
	private String tName="laxmi";
	@Resource(name="seats")
	private Seats seats;

	public Seats getSeats() {
		return seats;
	}

	public void setSeats(Seats seats) {
		this.seats = seats;
	}

	public int gettId() {
		return tId;
	}

	public void settId(int tId) {
		this.tId = tId;
	}

	public String gettName() {
		return tName;
	}

	public void settName(String tName) {
		this.tName = tName;
	}
}
